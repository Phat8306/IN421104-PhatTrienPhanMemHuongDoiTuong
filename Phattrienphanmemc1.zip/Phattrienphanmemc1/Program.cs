﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Phattrienphanmemc1
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

namespace Javalorant.Domain
{

        public class Customer
        {
            public Guid Id { get; private set; }
            public string Name { get; private set; }
            public string Phone { get; private set; }
            public int RewardPoints { get; private set; }

            private Customer(string name, string phone)
            {
                Id = Guid.NewGuid();
                Name = name;
                Phone = phone;
                RewardPoints = 0;
            }
            public static Customer Create(string name, string phone)
            {
                if (string.IsNullOrWhiteSpace(name))
                    throw new ArgumentException("Tên không được trống.");
                if (string.IsNullOrWhiteSpace(phone) || phone.Length < 10)
                    throw new ArgumentException("Số điện thoại không hợp lệ.");

                return new Customer(name.Trim(), phone.Trim());
            }

            public void AddPoints(int points)
            {
                if (points < 0) throw new ArgumentException("Điểm cộng phải lớn hơn 0.");
                RewardPoints += points;
            }
        }

        public class Product
        {
            public Guid Id { get; private set; }
            public string Name { get; private set; }
            public decimal Price { get; private set; }
            public int Stock { get; private set; }

            private Product(string name, decimal price, int stock)
            {
                Id = Guid.NewGuid();
                Name = name;
                Price = price;
                Stock = stock;
            }

            public static Product Create(string name, decimal price, int stock)
            {
                if (string.IsNullOrWhiteSpace(name))
                    throw new ArgumentException("Tên sản phẩm không được trống.");
                if (price <= 0)
                    throw new ArgumentOutOfRangeException(nameof(price), "Giá phải lớn hơn 0.");
                if (stock < 0)
                    throw new ArgumentOutOfRangeException(nameof(stock), "Tồn kho không được âm.");

                return new Product(name.Trim(), price, stock);
            }

            // Nghiệp vụ: Giảm tồn kho khi bán
            public void DecreaseStock(int quantity)
            {
                if (quantity <= 0) throw new ArgumentException("Số lượng giảm phải lớn hơn 0.");
                if (Stock < quantity) throw new InvalidOperationException($"Sản phẩm '{Name}' không đủ tồn kho.");
                Stock -= quantity;
            }
        }

        // 3. Thực thể Ca làm việc
        public class CashShift
        {
            public Guid Id { get; private set; }
            public DateTime StartTime { get; private set; }
            public decimal InitialCash { get; private set; }
            public bool IsClosed { get; private set; }

            private CashShift(decimal initialCash)
            {
                Id = Guid.NewGuid();
                StartTime = DateTime.Now;
                InitialCash = initialCash;
                IsClosed = false;
            }

            public static CashShift Create(decimal initialCash)
            {
                if (initialCash < 0)
                    throw new ArgumentOutOfRangeException(nameof(initialCash), "Tiền đầu ca không được âm.");
                return new CashShift(initialCash);
            }

            public void CloseShift()
            {
                if (IsClosed) throw new InvalidOperationException("Ca làm việc đã được đóng trước đó.");
                IsClosed = true;
            }
        }

        // 4. Thực thể Chi tiết Hóa đơn (OrderItem)
        public class OrderItem
        {
            public Guid Id { get; private set; }
            public Guid ProductId { get; private set; }
            public int Quantity { get; private set; }
            public decimal UnitPrice { get; private set; }

            private OrderItem(Guid productId, int quantity, decimal unitPrice)
            {
                Id = Guid.NewGuid();
                ProductId = productId;
                Quantity = quantity;
                UnitPrice = unitPrice;
            }

            public static OrderItem Create(Guid productId, int quantity, decimal unitPrice)
            {
                if (quantity <= 0) throw new ArgumentOutOfRangeException(nameof(quantity), "Số lượng phải > 0.");
                if (unitPrice < 0) throw new ArgumentOutOfRangeException(nameof(unitPrice), "Giá không được âm.");
                return new OrderItem(productId, quantity, unitPrice);
            }
        }

        // 5. Thực thể Hóa đơn
        public class Order
        {
            public Guid Id { get; private set; }
            public Guid CashShiftId { get; private set; }
            public Guid? CustomerId { get; private set; }
            public DateTime OrderDate { get; private set; }
            public string Status { get; private set; }
            public decimal TotalAmount { get; private set; }

            // Danh sách chi tiết HĐ, chỉ cho phép xem (IReadOnlyList)
            private readonly List<OrderItem> _items = new();
            public IReadOnlyList<OrderItem> Items => _items.AsReadOnly();

            private Order(Guid cashShiftId, Guid? customerId)
            {
                Id = Guid.NewGuid();
                CashShiftId = cashShiftId;
                CustomerId = customerId;
                OrderDate = DateTime.Now;
                Status = "Pending";
                TotalAmount = 0;
            }

            public static Order Create(CashShift cashShift, Customer? customer = null)
            {
                ArgumentNullException.ThrowIfNull(cashShift);
                if (cashShift.IsClosed)
                    throw new InvalidOperationException("Không thể tạo hóa đơn vì ca làm việc đã đóng.");

                return new Order(cashShift.Id, customer?.Id);
            }

            public void AddItem(Product product, int quantity)
            {
                if (Status != "Pending")
                    throw new InvalidOperationException("Chỉ thêm được sản phẩm khi hóa đơn đang chờ.");

                var item = OrderItem.Create(product.Id, quantity, product.Price);
                _items.Add(item);
                TotalAmount += item.Quantity * item.UnitPrice;
            }

            public void Pay(List<Product> storeProducts, Customer? customer = null)
            {
                if (Status != "Pending")
                    throw new InvalidOperationException($"Hóa đơn đang ở trạng thái {Status}.");
                if (_items.Count == 0)
                    throw new InvalidOperationException("Hóa đơn trống, không thể thanh toán.");

                // Trừ tồn kho thực tế
                foreach (var item in _items)
                {
                    var product = storeProducts.First(p => p.Id == item.ProductId);
                    product.DecreaseStock(item.Quantity);
                }

                // Cộng điểm thành viên (ví dụ 10.000đ = 1 điểm)
                if (customer != null)
                {
                    customer.AddPoints((int)(TotalAmount / 10000));
                }

                Status = "Paid";
            }
        }
    }
