# Hệ thống Quản lý cửa hàng Javalorant

Thông tin sinh viên:
- Họ và tên: Nguyễn Diệp Phát
- MSSV: 0024417763
- Bài tập: HĐ1.3 - Phân tích yêu cầu và Domain Modeling (Chương 1)

 # Các tính năng đã cài đặt (Domain Classes)
Dự án áp dụng chặt chẽ các nguyên lý OOP (private set, private constructor, Factory method `Create()`) cho 5 thực thể:
1. `Customer`: Quản lý khách hàng hội viên và tích điểm.
2. `Product`: Quản lý hàng hóa, kiểm tra tồn kho không được âm.
3. `CashShift`: Quản lý ca làm việc của thu ngân.
4. `Order`: Xử lý hóa đơn, thanh toán, trừ tồn kho và bắt lỗi khi ca đã đóng.
5. `OrderItem`: Quản lý chi tiết từng món hàng trong hóa đơn.

